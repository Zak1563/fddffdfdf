Satisfactory Rebar Gun by ButterPuppet on Thingiverse: https://www.thingiverse.com/thing:3554128

Summary:
This model was ripped from the game.If you want the model of a certain machine or thing from the game please just ask.